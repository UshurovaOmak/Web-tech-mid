import React, { Component } from 'react';
import './App.css';

export class ProductItem extends Component{
	constructor(props){
		super(props);
	}
    handleClick = () => {
    	if(Products[this.props.index].isAdded === false){  
             this.props.onProductClicked(this.props.index);
    	     Products[this.props.index].isAdded = true;
    	} else {
    		this.props.onSecondClick(this.props.index);
    		Products[this.props.index].isAdded = false;

    	}
    	
    }
	render(){
		return(
			<div className = "productItem" onClick = {this.handleClick}>
			{this.props.name}
			{this.props.price}
			</div>
			);
	}
}