import React, { Component } from 'react';
import './App.css';
import ProductItem from './ProductItem';
var Products = [
{
	id: 1,name: "Milk",price: 300,isAdded: false
},
{
	id: 2,name: "Bread",price: 100,isAdded: false

},
{
    id: 3,name: "Ice-Cream",price: 150,isAdded: false
}
];



class Products extends Component{
	constructor(props){
		super(props);
		this.state = {
		   displayedProducts: Products,
           totalSum: 0
		}
	}
    onProductClicked = (index) =>{
    	let currPrice = this.state.totalSum;
    	let added = this.state.displayedProducts[index].price;
        let newPrice = currPrice + added;
        this.setState({
        	totalSum: newPrice
        }); 
    }
    onSecondClick = (index) =>{
      let currPrice = this.state.totalSum;
    	let added = this.state.displayedProducts[index].price;
        let newPrice = currPrice - added;
        this.setState({
        	totalSum: newPrice
        }); 
    }
	render(){
		return(
			<div className = "productsList">
			<h1 className = "h"> Products Catalogue</h1>
			<ul>

			{
		this.state.displayedProducts.map((product, index) =>{
					return <ProductItem
					 id = {product.id}
					 index = {index}
					 name = {product.name}
					 price = {product.price}
                     key = {index}
                     onProductClicked = {this.onProductClicked}
                     onSecondClick = {this.onSecondClick}
					/>
				})
			}
             
			</ul>
			<div className = "total">Total Sum of Products:  {this.state.totalSum} tenge </div>
			</div>
          
			);
	}
}

export default Products;