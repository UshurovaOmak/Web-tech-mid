import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css'; 




class App extends Component {
  constructor(props){
      super(props);
      this.state = {
        isHomeActive: false,isAboutActive: false,isContactActive: false
      }
  }
    handleHomeClicked = (e) =>{
      this.setState({
        isHomeActive: true,isAboutActive: false,isContactActive: false
      });
    }
    handleAboutClicked =(e) =>{
      this.setState({
        isAboutActive: true,isHomeActive: false,isContactActive: false
      });
    }
   handleContactClicked = (e) =>{
      this.setState({
        isHomeActive: false,isAboutActive: false,isContactActive: true
      });
    }
  render() {
    return (
      <div className="App">
       <h3 className =  "h">My Navigation Menu</h3>
        
        <button className = {this.state.isHomeActive === true ? "activeButton" : "Button"} 
            onClick = {this.handleHomeClicked}>Home</button>
        
        <button className = {this.state.isAboutActive === true ? "activeButton" : "Button"} 
           onClick  = {this.handleAboutClicked}>About</button>
        
        <button className = {this.state.isContactActive === true ? "activeButton" : "Button"}
        onClick = {this.handleContactClicked}>Contact</button>
      </div>
    );
  }
}

export default App;